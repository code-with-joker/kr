# **App Name**: Impresso

## Core Features:

- Image Upload: Users can upload images directly from their device via a file input.
- Image Preview: Display the original and compressed images side by side.
- Compression Control: Allow users to select a target size for the compressed image, either in KB or MB, using a slider or numeric input. The application will compress the image optimally to approach the user specified size using trial and error with different compression parameters.
- Ad Integration & Legal Pages: Provide prominent advertisement spaces with clear instructions on where to insert the AdSense Ad Unit ID, along with a footer containing links to the Privacy Policy, Terms & Conditions, About Us, and Contact Us pages.

## Style Guidelines:

- Primary color: Deep Teal (#008080) for a professional and trustworthy feel.
- Secondary color: Light Gray (#F0F0F0) for backgrounds and content separation.
- Accent: Bright Cyan (#00FFFF) for interactive elements and highlights, indicating actionable items.
- Clean, minimalist layout with a focus on image preview and compression options. Use a grid system for responsiveness.
- Use a consistent set of line icons for a modern, premium look.
- Subtle transitions and animations for feedback during image processing.