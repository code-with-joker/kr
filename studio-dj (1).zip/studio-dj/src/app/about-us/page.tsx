import type { Metadata } from 'next';
import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Target, Zap, ShieldCheck } from 'lucide-react';

export const metadata: Metadata = {
  title: 'About Us',
  description: 'Learn more about Krita Compress, your go-to online image compression tool.',
};

export default function AboutUsPage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <Card className="shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-primary">About Krita Compress</CardTitle>
          <p className="text-muted-foreground text-lg">Your Privacy-Focused Image Compression Solution</p>
        </CardHeader>
        <CardContent className="space-y-8 text-muted-foreground">
          <section className="text-center">
            <Image 
              src="https://placehold.co/600x300.png" 
              alt="Krita Compress team or abstract graphic" 
              width={600} 
              height={300}
              className="rounded-lg mx-auto shadow-md mb-6"
              data-ai-hint="technology abstract"
            />
            <p className="text-lg leading-relaxed">
              Krita Compress was born from a simple idea: image compression should be easy, effective, and above all, private. 
              In a digital world where data privacy is paramount, we believe you shouldn&apos;t have to upload your sensitive images to a server just to reduce their file size.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-foreground mb-4 text-center">Our Mission</h2>
            <p className="text-center leading-relaxed mb-6">
              To provide a powerful, user-friendly image compression tool that respects your privacy by processing everything directly in your web browser. We aim to help individuals and businesses optimize their images for the web without compromising on security or quality.
            </p>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="flex flex-col items-center text-center p-4">
                <Target className="w-12 h-12 text-primary mb-3" />
                <h3 className="text-xl font-semibold text-foreground mb-1">Precision</h3>
                <p className="text-sm">Compress images to your exact target size in KB or MB.</p>
              </div>
              <div className="flex flex-col items-center text-center p-4">
                <Zap className="w-12 h-12 text-primary mb-3" />
                <h3 className="text-xl font-semibold text-foreground mb-1">Speed & Efficiency</h3>
                <p className="text-sm">Fast client-side processing means quick results without waiting for uploads.</p>
              </div>
              <div className="flex flex-col items-center text-center p-4">
                <ShieldCheck className="w-12 h-12 text-primary mb-3" />
                <h3 className="text-xl font-semibold text-foreground mb-1">Privacy First</h3>
                <p className="text-sm">Your images stay on your device. We never see or store them.</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-foreground mb-4 text-center">Why Krita Compress?</h2>
            <p className="leading-relaxed">
              We understand the need for smaller image files – for faster websites, easier sharing, and saving storage space. 
              Existing tools often require uploads or compromise on control. Krita Compress puts you in charge, offering a transparent process that happens entirely on your computer.
            </p>
            <p className="leading-relaxed mt-2">
              Whether you&apos;re a web developer, blogger, photographer, or just someone looking to shrink an image, Krita Compress is designed for you. We are constantly working to improve our tool and add new features, always keeping our core values of privacy, usability, and performance in mind.
            </p>
          </section>
          
          <section className="text-center">
             <h2 className="text-2xl font-semibold text-foreground mb-4">Get in Touch</h2>
             <p className="leading-relaxed">
                We value your feedback! If you have any questions, suggestions, or just want to say hello, please visit our <a href="/contact-us" className="text-primary hover:underline">Contact Us</a> page.
             </p>
          </section>
        </CardContent>
      </Card>
    </div>
  );
}
