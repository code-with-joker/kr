
import type { Metadata } from 'next';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ContactForm } from '@/components/contact/ContactForm';
import { z } from 'zod';

export const metadata: Metadata = {
  title: 'Contact Us',
  description: 'Get in touch with the Krita Compress team. We value your feedback and inquiries.',
};

// Define the schema for form data validation
const contactFormSchema = z.object({
  name: z.string().min(1, "Name is required."),
  email: z.string().email("Invalid email address."),
  message: z.string().min(1, "Message is required."),
});

export interface ContactFormState {
  success: boolean;
  message: string;
  errors?: {
    name?: string[];
    email?: string[];
    message?: string[];
    _form?: string[];
  }
}

// Server action to handle form submission
export async function submitContactForm(formData: FormData): Promise<ContactFormState> {
  "use server";

  const rawFormData = {
    name: formData.get("name"),
    email: formData.get("email"),
    message: formData.get("message"),
  };

  const validatedFields = contactFormSchema.safeParse(rawFormData);

  if (!validatedFields.success) {
    console.log("Form validation failed:", validatedFields.error.flatten().fieldErrors);
    return {
      success: false,
      message: "Validation failed. Please check your input.",
      errors: validatedFields.error.flatten().fieldErrors,
    };
  }
  
  const { name, email, message } = validatedFields.data;

  console.log("Form submitted successfully (server log):");
  console.log("Name:", name);
  console.log("Email:", email);
  console.log("Message:", message);

  // ** DEVELOPER NOTE: Integrate your email sending logic here **
  // For example, using a service like Resend, SendGrid, or Nodemailer:
  //
  // try {
  //   await resend.emails.send({
  //     from: 'Krita Compress Contact Form <onboarding@resend.dev>', // Replace with your "from" email
  //     to: 'kritacompresscontact@gmail.com',
  //     subject: `New Contact Form Submission from ${name}`,
  //     html: `<p>Name: ${name}</p><p>Email: ${email}</p><p>Message: ${message}</p>`,
  //   });
  //   return { success: true, message: "Thank you for your message! We'll get back to you soon." };
  // } catch (error) {
  //   console.error("Email sending error:", error);
  //   return { success: false, message: "Failed to send message. Please try again later." };
  // }
  // ***************************************************************

  // Placeholder success response (remove when actual email sending is implemented)
  return { success: true, message: "Thank you for your message! We'll get back to you soon. (Note: This is a simulated response. Email sending not yet implemented.)" };
}


export default function ContactUsPage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <Card className="shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-primary">Contact Us</CardTitle>
          <CardDescription className="text-lg">We&apos;d love to hear from you! Send us your questions, feedback, or suggestions.</CardDescription>
        </CardHeader>
        <CardContent>
          <ContactForm formAction={submitContactForm} />
          <p className="text-center text-sm text-muted-foreground mt-8">
            Alternatively, you can reach us at <a href="mailto:kritacompresscontact@gmail.com" className="text-primary hover:underline">kritacompresscontact@gmail.com</a>.
          </p>
           <p className="text-center text-xs text-muted-foreground mt-2">
            Note: For live email functionality, the server action needs to be configured with an email sending service.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
