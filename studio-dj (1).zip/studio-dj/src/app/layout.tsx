import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import Script from 'next/script';
import './globals.css';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: {
    default: 'Krita Compress - Compress Images to KB/MB',
    template: '%s | Krita Compress',
  },
  description: 'Optimize your images with Krita Compress. Easily compress JPEGs, PNGs, and WEBP images to a specific target file size in KB or MB, right in your browser. Fast, private, and free online image compressor.',
  keywords: ['image compressor', 'kb compressor', 'mb compressor', 'optimize images', 'reduce image size', 'jpeg compression', 'png compression', 'webp compression', 'krita compress', 'image optimizer', 'file shrinker'],
  robots: 'index, follow',
  openGraph: {
    title: 'Krita Compress - Online Image Compressor (KB/MB)',
    description: 'Optimize images to your desired file size (KB/MB) directly in your browser. Fast, private, and free with Krita Compress.',
    type: 'website',
    locale: 'en_US',
    url: 'https://kritacompress.app', // Replace with your actual domain if different
    siteName: 'Krita Compress',
    // images: [ // TODO: Add a specific OG image for sharing
    //   {
    //     url: 'https://kritacompress.app/og-image.png', // Example: /public/og-image.png
    //     width: 1200,
    //     height: 630,
    //     alt: 'Krita Compress - Image Compressor Tool',
    //   },
    // ],
  },
  // manifest: '/site.webmanifest', // TODO: Add a web app manifest for PWA capabilities
  // icons: { // TODO: Add favicons
  //   icon: [
  //     { url: '/favicon.ico', sizes: 'any' },
  //     { url: '/icon.svg', type: 'image/svg+xml' },
  //   ],
  //   apple: '/apple-touch-icon.png',
  // },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* 
          Google AdSense Integration:
          1. After your AdSense account is approved and set up, uncomment the <Script> tag below.
          2. Replace 'ca-pub-YOUR_ADSENSE_PUBLISHER_ID' with your actual AdSense Publisher ID.
          3. Ensure you comply with all AdSense program policies.
        */}
        {/*
        <Script
          async
          id="adsense-script"
          src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-YOUR_ADSENSE_PUBLISHER_ID`}
          crossOrigin="anonymous"
          strategy="afterInteractive"
        />
        */}
      </head>
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased flex flex-col min-h-screen`}>
        <Header />
        <main className="flex-grow container mx-auto px-4 py-8">
          {children}
        </main>
        <Footer />
        <Toaster />
      </body>
    </html>
  );
}
