
import { ImageCompressorTool } from '@/components/impresso/ImageCompressorTool';
import { AdPlaceholder } from '@/components/impresso/AdPlaceholder';
import type { Metadata } from 'next';
// import Image from 'next/image';  // Image component is no longer used here
import { Zap, ShieldCheck, Target } from 'lucide-react';
import { Typewriter } from '@/components/effects/Typewriter';

export const metadata: Metadata = {
  title: 'Krita Compress - Online Image Compressor (KB/MB)',
  description: 'Compress JPEG/PNG images to a specific size in KB or MB. Shrink your images like magic. Fast, free, and secure client-side image optimization with Krita Compress.',
};

export default function HomePage() {
  return (
    <div className="w-full">
      <section className="text-center py-12 md:py-16">
        <div className="grid md:grid-cols-1 items-center gap-8 mb-8"> {/* Changed to md:grid-cols-1 since image is removed */}
          <div className="text-left md:text-center">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-primary mb-6 tracking-tight">
              Krita Compress Image Compressor
            </h1>
            <div className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed h-16 md:h-10">
              <Typewriter text="Shrink your images like magic." speed={70} loop={true} delay={2000} />
            </div>
          </div>
          {/* 
            The Image component for 'krita-compress-logo-hero.png' has been removed from here.
          */}
        </div>
        <p className="text-base md:text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
          Easily reduce your image file sizes to your desired KB or MB target. 
          All processing is done directly in your browser for maximum privacy and speed.
        </p>
      </section>

      <AdPlaceholder adSlotId="YOUR_ADSENSE_AD_SLOT_ID_HOMEPAGE_TOP" className="mb-10" />
      
      <div id="image-compressor-section">
        <ImageCompressorTool />
      </div>

      <AdPlaceholder adSlotId="YOUR_ADSENSE_AD_SLOT_ID_HOMEPAGE_BOTTOM" className="mt-16" />

      <section className="mt-20 mb-12 text-center">
        <h2 className="text-3xl font-semibold text-foreground mb-10">Why Choose Krita Compress?</h2>
        <div className="grid md:grid-cols-3 gap-8 text-left">
          <div className="p-8 rounded-xl glassmorphism-card">
            <ShieldCheck className="w-12 h-12 text-primary mb-4" />
            <h3 className="text-2xl font-semibold text-foreground mb-3">Privacy First</h3>
            <p className="text-base text-muted-foreground">Images are processed locally in your browser. Nothing is uploaded to our servers, ensuring your data remains private.</p>
          </div>
          <div className="p-8 rounded-xl glassmorphism-card">
            <Target className="w-12 h-12 text-primary mb-4" />
            <h3 className="text-2xl font-semibold text-foreground mb-3">Target Size Compression</h3>
            <p className="text-base text-muted-foreground">Specify your desired file size in KB or MB, and Krita Compress will optimize your image to meet that target precisely.</p>
          </div>
          <div className="p-8 rounded-xl glassmorphism-card">
            <Zap className="w-12 h-12 text-primary mb-4" />
            <h3 className="text-2xl font-semibold text-foreground mb-3">Free & Easy to Use</h3>
            <p className="text-base text-muted-foreground">A simple, intuitive interface makes image compression accessible to everyone, completely free of charge.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
