import type { Metadata } from 'next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export const metadata: Metadata = {
  title: 'Terms & Conditions',
  description: 'Terms and Conditions for using Krita Compress - Online Image Compressor.',
};

export default function TermsConditionsPage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-primary">Terms & Conditions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 text-muted-foreground">
          <p className="text-sm">Last updated: {new Date().toLocaleDateString()}</p>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">1. Acceptance of Terms</h2>
            <p>By accessing and using Krita Compress (the &quot;Service&quot;), you agree to be bound by these Terms &amp; Conditions (&quot;Terms&quot;). If you do not agree to all of these Terms, do not use this Service.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">2. Service Description</h2>
            <p>Krita Compress provides an online tool for compressing image files. All image processing is performed locally within your web browser; no image data is transmitted to our servers.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">3. User Responsibilities</h2>
            <p>You are solely responsible for the images you choose to process using Krita Compress. You agree not to use the Service to compress images that:</p>
            <ul className="list-disc list-inside ml-4 space-y-1">
              <li>Infringe upon any third party&apos;s copyright, patent, trademark, trade secret, or other proprietary rights or rights of publicity or privacy.</li>
              <li>Are illegal, defamatory, abusive, harassing, obscene, or otherwise objectionable.</li>
            </ul>
            <p>You acknowledge that Krita Compress does not review or pre-screen content, but we reserve the right (though not the obligation) to refuse or remove any content processed through the service if it violates these terms.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">4. Intellectual Property</h2>
            <p>The Service and its original content (excluding content provided by users), features, and functionality are and will remain the exclusive property of Krita Compress and its licensors. The Service is protected by copyright, trademark, and other laws of both domestic and foreign countries.</p>
          </section>
          
          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">5. Advertisements</h2>
            <p>The Service may display advertisements. Your interactions with advertisers found on or through the Service are solely between you and such advertisers. You agree that we shall not be responsible or liable for any loss or damage of any sort incurred as the result of any such dealings or as the result of the presence of such advertisers on the Service.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">6. Disclaimer of Warranties</h2>
            <p>The Service is provided on an &quot;AS IS&quot; and &quot;AS AVAILABLE&quot; basis. Your use of the Service is at your sole risk. Krita Compress expressly disclaims all warranties of any kind, whether express or implied, including, but not limited to, the implied warranties of merchantability, fitness for a particular purpose, and non-infringement.</p>
            <p>Krita Compress makes no warranty that the Service will be uninterrupted, timely, secure, or error-free, or that the results obtained from the use of the Service will be accurate or reliable.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">7. Limitation of Liability</h2>
            <p>In no event shall Krita Compress, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from (i) your access to or use of or inability to access or use the Service; (ii) any conduct or content of any third party on the Service; (iii) any content obtained from the Service; and (iv) unauthorized access, use or alteration of your transmissions or content, whether based on warranty, contract, tort (including negligence) or any other legal theory, whether or not we have been informed of the possibility of such damage.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">8. Changes to Terms</h2>
            <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material, we will try to provide at least 30 days&apos; notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.</p>
            <p>By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised terms.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">9. Governing Law</h2>
            <p>These Terms shall be governed and construed in accordance with the laws of [Your Jurisdiction - e.g., State of California, USA], without regard to its conflict of law provisions.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">10. Contact Us</h2>
            <p>If you have any questions about these Terms, please contact us via the information on our Contact Us page.</p>
          </section>
        </CardContent>
      </Card>
    </div>
  );
}
