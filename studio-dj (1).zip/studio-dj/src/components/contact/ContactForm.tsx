
'use client';

import type { FC } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Mail, MessageSquare, User, Loader2 } from 'lucide-react';
import type { submitContactForm } from '@/app/contact-us/page'; // Import the type

const contactFormSchema = z.object({
  name: z.string().min(2, { message: 'Name must be at least 2 characters.' }),
  email: z.string().email({ message: 'Please enter a valid email address.' }),
  message: z.string().min(10, { message: 'Message must be at least 10 characters.' }),
});

export type ContactFormData = z.infer<typeof contactFormSchema>;

interface ContactFormProps {
  formAction: typeof submitContactForm;
}

export const ContactForm: FC<ContactFormProps> = ({ formAction }) => {
  const { toast } = useToast();
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    reset,
  } = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
  });

  const onSubmit = async (data: ContactFormData) => {
    try {
      const formData = new FormData();
      formData.append('name', data.name);
      formData.append('email', data.email);
      formData.append('message', data.message);

      const result = await formAction(formData);

      if (result.success) {
        toast({
          title: 'Message Sent!',
          description: result.message,
        });
        reset(); // Reset form fields
      } else {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: result.message || 'An unexpected error occurred.',
        });
      }
    } catch (error) {
      console.error('Form submission error:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to send message. Please try again later.',
      });
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <Label htmlFor="name" className="flex items-center mb-1">
          <User className="w-4 h-4 mr-2 text-muted-foreground" /> Your Name
        </Label>
        <Input
          id="name"
          {...register('name')}
          placeholder="John Doe"
          disabled={isSubmitting}
          className={errors.name ? 'border-destructive' : ''}
        />
        {errors.name && <p className="text-sm text-destructive mt-1">{errors.name.message}</p>}
      </div>
      <div>
        <Label htmlFor="email" className="flex items-center mb-1">
          <Mail className="w-4 h-4 mr-2 text-muted-foreground" /> Your Email
        </Label>
        <Input
          id="email"
          type="email"
          {...register('email')}
          placeholder="you@example.com"
          disabled={isSubmitting}
          className={errors.email ? 'border-destructive' : ''}
        />
        {errors.email && <p className="text-sm text-destructive mt-1">{errors.email.message}</p>}
      </div>
      <div>
        <Label htmlFor="message" className="flex items-center mb-1">
          <MessageSquare className="w-4 h-4 mr-2 text-muted-foreground" /> Your Message
        </Label>
        <Textarea
          id="message"
          {...register('message')}
          rows={5}
          placeholder="How can we help you?"
          disabled={isSubmitting}
          className={errors.message ? 'border-destructive' : ''}
        />
        {errors.message && <p className="text-sm text-destructive mt-1">{errors.message.message}</p>}
      </div>
      <div className="text-center">
        <Button type="submit" className="w-full md:w-auto px-8" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Sending...
            </>
          ) : (
            'Send Message'
          )}
        </Button>
      </div>
    </form>
  );
};
