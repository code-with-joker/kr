// src/components/effects/LottiePlayer.tsx
'use client';

import Lottie, { type LottieComponentProps } from 'lottie-react';
import { cn } from '@/lib/utils';

interface LottiePlayerProps extends Omit<LottieComponentProps, 'animationData'> {
  animationData: any; // Lottie JSON data
  className?: string;
}

export function LottiePlayer({ animationData, className, ...props }: LottiePlayerProps) {
  if (!animationData) {
    // If no animation data is provided, render nothing.
    // The parent component should handle the primary fallback UI (e.g., static icon, progress bar).
    return null;
  }

  return (
    <Lottie
      animationData={animationData}
      className={cn("w-full h-auto", className)}
      loop={true}
      autoplay={true}
      {...props}
    />
  );
}

/**
 * How to use:
 * 1. Import this component: `import { LottiePlayer } from '@/components/effects/LottiePlayer';`
 * 2. Get your Lottie JSON file (e.g., from LottieFiles) and place it in your project (e.g., `/public/lottie/your-animation.json`)
 *    Or import it directly if your setup allows: `import YourAnimation from '@/path/to/your-animation.json';`
 * 3. Use the component:
 *    `<LottiePlayer animationData={YourAnimation} className="w-32 h-32" />`
 * 
 * Note: For animations from `/public`, you'll need to fetch them and pass the JSON data.
 * Example fetching from public folder:
 * ```tsx
 * import { LottiePlayer } from '@/components/effects/LottiePlayer';
 * import { useState, useEffect } from 'react';
 * 
 * function MyComponentWithLottie() {
 *   const [animation, setAnimation] = useState(null);
 * 
 *   useEffect(() => {
 *     fetch('/lottie/your-animation.json')
 *       .then(response => response.json())
 *       .then(data => setAnimation(data))
 *       .catch(error => console.error('Error loading Lottie animation:', error));
 *   }, []);
 * 
 *   if (!animation) return <div>Loading animation...</div>;
 * 
 *   return <LottiePlayer animationData={animation} />;
 * }
 * ```
 */
