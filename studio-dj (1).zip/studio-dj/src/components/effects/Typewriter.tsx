// src/components/effects/Typewriter.tsx
'use client';

import type { HTMLAttributes } from 'react';
import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface TypewriterProps extends HTMLAttributes<HTMLSpanElement> {
  text: string;
  speed?: number;
  loop?: boolean;
  delay?: number;
}

export function Typewriter({ text, speed = 100, loop = false, delay = 1000, className, ...props }: TypewriterProps) {
  const [displayedText, setDisplayedText] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    if (!text) return;

    const handleTyping = () => {
      if (isDeleting) {
        setDisplayedText((prev) => prev.substring(0, prev.length - 1));
        setCurrentIndex((prev) => prev - 1);
      } else {
        setDisplayedText((prev) => text.substring(0, prev.length + 1));
        setCurrentIndex((prev) => prev + 1);
      }
    };

    if (isDeleting && displayedText === '') {
      setIsDeleting(false);
      setCurrentIndex(0);
      if (loop) {
        // Optional: Add a delay before re-typing if looping
        setTimeout(() => {}, delay);
      } else {
        return; // Stop if not looping and finished deleting
      }
    } else if (!isDeleting && displayedText === text) {
      if (loop) {
        setTimeout(() => setIsDeleting(true), delay);
      } else {
        return; // Stop if not looping and finished typing
      }
    }

    const timeoutId = setTimeout(handleTyping, isDeleting ? speed / 2 : speed);
    return () => clearTimeout(timeoutId);
  }, [displayedText, text, isDeleting, speed, loop, delay, currentIndex]);

  return (
    <span className={cn("inline", className)} {...props}>
      {displayedText}
      <span className="typewriter-caret" />
    </span>
  );
}
