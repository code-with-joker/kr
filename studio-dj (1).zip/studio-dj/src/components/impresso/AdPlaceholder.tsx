'use client';

import { useEffect } from 'react';
import { cn } from '@/lib/utils';

interface AdPlaceholderProps {
  adSlotId: string;
  className?: string;
  isResponsive?: boolean;
}

export function AdPlaceholder({ adSlotId, className, isResponsive = true }: AdPlaceholderProps) {
  useEffect(() => {
    // This is a placeholder for AdSense initialization logic.
    // The main AdSense script should be in RootLayout.
    // This attempts to push an ad to an existing AdSense queue.
    try {
      ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
    } catch (e) {
      // It's common for this to throw an error in development if AdSense isn't fully loaded
      // or if ad-blockers are active. You can safely ignore these errors during development.
      // console.error("AdSense push error (can be ignored in dev):", e);
    }
  }, [adSlotId]);

  return (
    <div className={cn("my-4 flex min-h-[100px] items-center justify-center border-2 border-dashed border-muted-foreground/30 bg-muted/50 p-4 text-center text-muted-foreground shadow-inner rounded-md", className)}>
      <div>
        <p className="font-semibold">Advertisement Area</p>
        <p className="text-xs mt-1">
          This is a placeholder for an ad unit.
        </p>
        <div className="mt-2 p-2 bg-background border border-border rounded text-xs">
          <p>To activate this ad slot for production:</p>
          <ol className="list-decimal list-inside text-left">
            <li>Ensure the main AdSense script in `src/app/layout.tsx` is uncommented and has your Publisher ID.</li>
            <li>Get your Ad Unit ID from your AdSense account for this specific ad placement.</li>
            <li>Replace this entire `AdPlaceholder` component instance in your page with the ad code snippet provided by AdSense.</li>
            <li>Alternatively, modify this component to render the AdSense code directly when ads are enabled.</li>
          </ol>
          <p className="mt-2 font-medium">Example AdSense code structure:</p>
          <pre className="mt-1 p-2 bg-muted rounded-sm text-xs overflow-auto">
            <code>
{`<!-- Ad Unit: ${adSlotId} -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-YOUR_ADSENSE_PUBLISHER_ID" 
     data-ad-slot="${adSlotId}" <!-- Replace with your Ad Unit ID -->
     data-ad-format="auto"${isResponsive ? `
     data-full-width-responsive="true"` : ''}>
</ins>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({});
</script>`}
            </code>
          </pre>
           <p className="mt-2 text-amber-600 dark:text-amber-400 text-xs">
            This placeholder is for development & layout purposes. For live ads, integrate the official AdSense snippet.
           </p>
        </div>
      </div>
    </div>
  );
}
