// src/components/impresso/ImageCompressorTool.tsx
'use client';

import { useState, ChangeEvent, useEffect, useRef } from 'react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { UploadCloud, Image as ImageIcon, Download, AlertCircle, CheckCircle2, Settings2, Info, Sparkles } from 'lucide-react';
import { compressImageToTargetSize, formatBytes, TargetUnit } from '@/lib/image-utils';
import { useToast } from "@/hooks/use-toast";
import { LottiePlayer } from '@/components/effects/LottiePlayer';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

// Placeholder for Lottie animation data. Replace with actual imported JSON or fetched data.
// Option 1: Import JSON directly (if your bundler/setup supports it)
// import CompressingAnimation from '@/../public/lottie/compressing-animation.json'; 
// import SuccessAnimation from '@/../public/lottie/success-animation.json';
// import ErrorAnimation from '@/../public/lottie/error-animation.json';
// Option 2: Or fetch from public (see LottiePlayer.tsx for example)

const compressingAnimationData = null; // Replace with actual data for compressing state
const uploadSuccessAnimationData = null; // Replace with actual data for success alert
const errorAnimationData = null; // Replace with actual data for error alert


export function ImageCompressorTool() {
  const [originalImage, setOriginalImage] = useState<File | null>(null);
  const [originalImageURL, setOriginalImageURL] = useState<string | null>(null);
  const [originalSize, setOriginalSize] = useState<number | null>(null);

  const [compressedImageURL, setCompressedImageURL] = useState<string | null>(null);
  const [compressedBlob, setCompressedBlob] = useState<Blob | null>(null);
  const [compressedSize, setCompressedSize] = useState<number | null>(null);
  const [compressionQuality, setCompressionQuality] = useState<number | null>(null);

  const [targetSizeInput, setTargetSizeInput] = useState<string>('500');
  const [targetUnit, setTargetUnit] = useState<TargetUnit>('KB');
  
  const [isCompressing, setIsCompressing] = useState<boolean>(false);
  const [compressionProgress, setCompressionProgress] = useState<number>(0);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  
  const [animateDownloadButton, setAnimateDownloadButton] = useState(false);

  useEffect(() => {
    return () => {
      if (originalImageURL) URL.revokeObjectURL(originalImageURL);
      if (compressedImageURL) URL.revokeObjectURL(compressedImageURL);
    };
  }, [originalImageURL, compressedImageURL]);

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
        setError('Invalid file type. Please upload a JPEG, PNG, or WEBP image.');
        toast({ variant: "destructive", title: "Invalid File Type", description: "Please upload a JPEG, PNG, or WEBP image." });
        return;
      }
      if (file.size > 20 * 1024 * 1024) { // 20MB limit
        setError('File is too large. Maximum size is 20MB.');
        toast({ variant: "destructive", title: "File Too Large", description: "Maximum upload size is 20MB." });
        return;
      }

      setOriginalImage(file);
      setOriginalSize(file.size);
      if (originalImageURL) URL.revokeObjectURL(originalImageURL);
      setOriginalImageURL(URL.createObjectURL(file));
      
      if (compressedImageURL) URL.revokeObjectURL(compressedImageURL);
      setCompressedImageURL(null);
      setCompressedBlob(null);
      setCompressedSize(null);
      setCompressionQuality(null);
      setError(null);
      setSuccessMessage(null);
      setAnimateDownloadButton(false);
    }
  };

  const handleCompressImage = async () => {
    if (!originalImage) {
      setError('Please upload an image first.');
      toast({ variant: "destructive", title: "No Image", description: "Please upload an image first." });
      return;
    }

    const targetSize = parseFloat(targetSizeInput);
    if (isNaN(targetSize) || targetSize <= 0) {
      setError('Please enter a valid target size.');
      toast({ variant: "destructive", title: "Invalid Target Size", description: "Please enter a valid positive number for the target size." });
      return;
    }

    setIsCompressing(true);
    setCompressionProgress(0);
    setError(null);
    setSuccessMessage(null);
    if (compressedImageURL) URL.revokeObjectURL(compressedImageURL);
    setCompressedImageURL(null);
    setCompressedBlob(null);
    setCompressedSize(null);
    setCompressionQuality(null);
    setAnimateDownloadButton(false);

    let progressInterval: NodeJS.Timeout | undefined;
    if (!compressingAnimationData) { 
        progressInterval = setInterval(() => {
        setCompressionProgress(prev => (prev < 90 ? prev + 10 : prev));
        }, 200); 
    }


    try {
      const result = await compressImageToTargetSize(originalImage, targetSize, targetUnit);
      if (progressInterval) clearInterval(progressInterval);
      setCompressionProgress(100);

      if (result) {
        setCompressedBlob(result.blob);
        setCompressedImageURL(URL.createObjectURL(result.blob));
        setCompressedSize(result.blob.size);
        setCompressionQuality(result.quality);
        const successMsg = `Image compressed successfully to ${formatBytes(result.blob.size)}. (Quality: ${(result.quality * 100).toFixed(0)}%)`;
        setSuccessMessage(successMsg);
        toast({ title: "Compression Successful", description: successMsg });
        setAnimateDownloadButton(true); 
        setTimeout(() => setAnimateDownloadButton(false), 800); 

        if (originalSize && result.blob.size > originalSize) {
             toast({ variant: "default", title: "Note", description: "Compressed size is larger than original. Original image might be already highly optimized or target size too high." });
        }

      } else {
        const failMsg = 'Failed to compress image. The target size might be too small for this image or an unexpected error occurred.';
        setError(failMsg);
        toast({ variant: "destructive", title: "Compression Failed", description: failMsg });
      }
    } catch (err) {
      if (progressInterval) clearInterval(progressInterval);
      setCompressionProgress(100);
      console.error('Compression error:', err);
      const errorMsg = 'An unexpected error occurred during compression.';
      setError(errorMsg);
      toast({ variant: "destructive", title: "Error", description: errorMsg });
    } finally {
      setIsCompressing(false);
    }
  };

  const handleDownloadCompressed = () => {
    if (!compressedBlob || !compressedImageURL) return;
    const link = document.createElement('a');
    link.href = compressedImageURL;
    const originalNameParts = originalImage?.name.split('.') ?? ['compressed_image', 'jpg'];
    const extension = compressedBlob.type.split('/')[1] || originalNameParts.pop() || 'jpg';
    const nameWithoutExtension = originalNameParts.join('.');
    link.download = `${nameWithoutExtension}_compressed.${extension}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast({ title: "Download Started", description: `Downloading ${link.download}` });
  };
  
  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <Card className="w-full max-w-4xl mx-auto shadow-2xl rounded-xl overflow-hidden bg-card">
      <CardHeader className="border-b border-border/30">
        <CardTitle className="text-2xl flex items-center gap-2 text-foreground"><Sparkles className="text-primary" />Compress Your Images</CardTitle>
        <CardDescription className="text-muted-foreground">Upload an image, set your target size, and let us do the magic!</CardDescription>
      </CardHeader>
      <CardContent className="p-6 md:p-8 space-y-8">
        <div className="space-y-4">
          <Label htmlFor="image-upload" className="text-lg font-medium text-foreground">Upload Image</Label>
          <div 
            className="flex flex-col items-center justify-center w-full h-72 p-8 bg-card rounded-xl cursor-default border-2 border-dashed border-border/40 hover:border-primary/60 transition-colors duration-300"
            onDrop={(e) => { e.preventDefault(); if (e.dataTransfer.files) handleFileChange({ target: { files: e.dataTransfer.files } } as any);}}
            onDragOver={(e) => e.preventDefault()}
            onClick={triggerFileInput}
          >
            <UploadCloud className="w-16 h-16 text-primary-foreground mb-4" />
            <p className="text-lg text-foreground mb-4"> 
              Drop your images here or
            </p>
            <Button onClick={(e) => { e.stopPropagation(); triggerFileInput(); }} variant="default" size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
              Upload Files
            </Button>
            <p className="text-sm text-muted-foreground mt-6">JPEG, PNG, WEBP (Max 20MB)</p>
          </div>
          <Input 
            id="image-upload" 
            type="file" 
            className="hidden" 
            accept="image/jpeg,image/png,image/webp" 
            onChange={handleFileChange}
            ref={fileInputRef}
          />
           <div className="flex items-start p-4 rounded-lg bg-secondary/30 text-secondary-foreground border border-secondary/50 mt-4">
            <Info className="w-6 h-6 mr-3 shrink-0 mt-0.5 text-primary" />
            <div>
                <h4 className="font-semibold text-foreground">Privacy Guaranteed</h4>
                <p className="text-sm text-muted-foreground">All image processing happens directly in your browser. Your files are never uploaded to any server.</p>
            </div>
          </div>
        </div>

        {originalImage && (
          <div className="space-y-6 p-6 border border-border/50 rounded-xl bg-background/50"> 
            <h3 className="text-xl font-semibold flex items-center gap-2 text-foreground"><Settings2 className="text-primary"/>Set Target Size</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
              <div className="space-y-1.5">
                <Label htmlFor="target-size" className="font-medium text-foreground">Target Size</Label>
                <Input 
                  id="target-size" 
                  type="number" 
                  value={targetSizeInput} 
                  onChange={(e) => setTargetSizeInput(e.target.value)} 
                  placeholder="e.g., 500"
                  disabled={isCompressing}
                  className="h-11 text-base bg-input text-foreground placeholder:text-muted-foreground"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="target-unit" className="font-medium text-foreground">Unit</Label>
                <Select value={targetUnit} onValueChange={(value: string) => setTargetUnit(value as TargetUnit)} disabled={isCompressing}>
                  <SelectTrigger id="target-unit" className="h-11 text-base bg-input text-foreground">
                    <SelectValue placeholder="Select unit" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover text-popover-foreground">
                    <SelectItem value="KB">KB (Kilobytes)</SelectItem>
                    <SelectItem value="MB">MB (Megabytes)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleCompressImage} disabled={isCompressing || !originalImage} className="w-full md:w-auto h-11 text-base bg-primary hover:bg-primary/90 text-primary-foreground" size="lg">
                {isCompressing ? 'Compressing...' : 'Compress Image'}
              </Button>
            </div>
          </div>
        )}

        {isCompressing && (
          <div className="space-y-3 text-center p-4">
            {compressingAnimationData ? (
              <div className="flex flex-col items-center">
                <LottiePlayer animationData={compressingAnimationData} className="w-32 h-32" />
                <p className="text-sm text-muted-foreground mt-2">Optimizing your image, please wait...</p>
              </div>
            ) : (
              <div className="flex flex-col items-center space-y-3">
                 <Image 
                    src="https://placehold.co/128x128.png" 
                    alt="Compressing image indicator" 
                    width={80} 
                    height={80}
                    className="rounded-lg opacity-75"
                    data-ai-hint="file process"
                  />
                <p className="text-sm text-muted-foreground">Optimizing your image, please wait...</p>
                <Progress value={compressionProgress} className="w-3/4 h-2 bg-secondary mt-2" /> 
              </div>
            )}
          </div>
        )}

        {error && (
          <Alert variant="destructive" className="shadow-md">
            {errorAnimationData ? (
              <LottiePlayer animationData={errorAnimationData} className="h-10 w-10 -ml-1 -mt-1" loop={false} />
            ) : (
              <AlertCircle className="h-5 w-5" />
            )}
            <AlertTitle className="font-semibold">Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        {successMessage && !error && (
           <Alert variant="default" className="bg-accent/10 border-accent/30 text-accent shadow-md">
            {uploadSuccessAnimationData ? (
               <LottiePlayer animationData={uploadSuccessAnimationData} className="h-10 w-10 -ml-1 -mt-1" loop={false} />
            ) : (
              <CheckCircle2 className="h-5 w-5 text-accent" />
            )}
            <AlertTitle className="font-semibold text-current">Success</AlertTitle>
            <AlertDescription className="text-current opacity-90">{successMessage}</AlertDescription>
          </Alert>
        )}

        {(originalImageURL || compressedImageURL) && (
          <div className="grid md:grid-cols-2 gap-6 pt-6">
            {originalImageURL && originalSize !== null && (
              <Card className="overflow-hidden shadow-lg rounded-xl bg-card">
                <CardHeader className="bg-card border-b border-border/30">
                  <CardTitle className="flex items-center gap-2 text-lg text-foreground"><ImageIcon className="text-primary"/> Original Image</CardTitle>
                  <CardDescription className="font-medium text-muted-foreground">{formatBytes(originalSize)}</CardDescription>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="aspect-video relative w-full bg-background/50 rounded-md overflow-hidden border-2 border-dashed border-border/50">
                    <Image src={originalImageURL} alt="Original" layout="fill" objectFit="contain" data-ai-hint="abstract texture" />
                  </div>
                </CardContent>
              </Card>
            )}
            {compressedImageURL && compressedSize !== null && (
              <Card className="overflow-hidden shadow-lg rounded-xl border-2 border-primary bg-card">
                <CardHeader className="bg-primary/10 border-b border-primary/30">
                  <CardTitle className="flex items-center gap-2 text-lg text-primary"><ImageIcon /> Compressed Image</CardTitle>
                  <CardDescription className="font-medium text-primary/90">
                    {formatBytes(compressedSize)}
                    {originalSize && ` (${((1 - compressedSize / originalSize) * 100).toFixed(1)}% reduction)`}
                    {compressionQuality && ` (Q: ${(compressionQuality * 100).toFixed(0)}%)`}
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4 space-y-4">
                  <div className="aspect-video relative w-full bg-background/50 rounded-md overflow-hidden border-2 border-dashed border-primary/50">
                     <Image src={compressedImageURL} alt="Compressed" layout="fill" objectFit="contain" data-ai-hint="geometric pattern" />
                  </div>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button 
                          onClick={handleDownloadCompressed} 
                          className={cn("w-full text-base", animateDownloadButton && "bounce-animation")}
                          size="lg" 
                          variant="outline"
                        >
                          <Download className="mr-2 h-5 w-5" /> Download Compressed Image
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Click to Save!</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

