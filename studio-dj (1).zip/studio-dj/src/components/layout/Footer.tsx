import Link from 'next/link';
import { Instagram, Heart } from 'lucide-react'; // Changed from Github, Linkedin to Instagram

export function Footer() {
  const legalPages = [
    { href: '/privacy-policy', label: 'Privacy Policy' },
    { href: '/terms-conditions', label: 'Terms & Conditions' },
    { href: '/about-us', label: 'About Us' },
    { href: '/contact-us', label: 'Contact Us' },
  ];

  const socialLinks = [
    { href: 'https://www.instagram.com/kritam__singh?igsh=MTFmMjdlZmkycWlyeA==', label: 'Instagram', icon: Instagram, 'aria-label': 'Krita Compress on Instagram' },
    // Add more social links here
  ];

  return (
    <footer className="bg-muted text-muted-foreground mt-auto">
      <div className="container mx-auto px-4 py-8">
        <nav className="flex flex-wrap justify-center gap-x-6 gap-y-2 mb-6">
          {legalPages.map((page) => (
            <Link
              key={page.href}
              href={page.href}
              className="text-sm footer-link-hover"
            >
              {page.label}
            </Link>
          ))}
        </nav>

        <div className="flex justify-center space-x-4 mb-6">
          {socialLinks.map((social) => (
            <a
              key={social.label}
              href={social.href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={social['aria-label']}
              className="text-muted-foreground footer-link-hover"
            >
              <social.icon className="w-5 h-5" />
            </a>
          ))}
        </div>
        
        <div className="text-center text-sm space-y-2">
          <p>Images are processed in your browser and never uploaded to our servers.</p>
          <p className="flex items-center justify-center">
            Made by Krita Compress with <Heart className="w-4 h-4 text-primary mx-1.5" fill="currentColor" />
          </p>
          <p>&copy; {new Date().getFullYear()} Krita Compress. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
