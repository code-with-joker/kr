// src/components/layout/Header.tsx
'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Minimize2 } from 'lucide-react'; // Changed from Compress to Minimize2

const KritaCompressLogo = () => (
  <svg width="36" height="36" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-primary group-hover:text-primary/90 transition-colors">
    <path d="M20 15C20 12.2386 22.2386 10 25 10H60.3571L75 24.6429V85C75 87.7614 72.7614 90 70 90H25C22.2386 90 20 87.7614 20 85V15Z" stroke="currentColor" strokeWidth="6" strokeLinejoin="round"/>
    <path d="M59 10V26H75" stroke="currentColor" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="40" cy="40" r="8" className="fill-accent" stroke="currentColor" strokeWidth="4"/>
    <path d="M30 70L45 55L60 70H30Z" fill="hsl(var(--secondary))" stroke="currentColor" strokeWidth="4" strokeLinejoin="round"/>
    <path d="M50 65L50 80M45 75H55" stroke="hsl(var(--primary))" strokeWidth="6" strokeLinecap="round"/>
  </svg>
);

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleCompressNowClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    if (pathname === '/') {
      event.preventDefault();
      const section = document.getElementById('image-compressor-section');
      if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
      }
    }
    // If not on homepage, the Link component will handle navigation
  };

  const CompressNowButton = () => (
    <Button
      onClick={pathname === '/' ? handleCompressNowClick : undefined}
      size="sm"
      className="hidden sm:inline-flex items-center gap-1.5"
      aria-label="Compress Now"
    >
      <Minimize2 className="w-4 h-4" /> {/* Changed from Compress to Minimize2 */}
      Compress Now
    </Button>
  );

  return (
    <header 
      className={cn(
        "bg-background/80 backdrop-blur-md shadow-lg sticky top-0 z-50 border-b border-border/70 transition-all duration-300",
        isScrolled ? "py-2 sm:py-2" : "py-3 sm:py-4"
      )}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link 
          href="/" 
          className={cn(
            "flex items-center gap-2 sm:gap-3 text-primary hover:opacity-90 transition-opacity group",
            isScrolled ? "text-2xl" : "text-2xl sm:text-3xl" 
          )}
        >
          <KritaCompressLogo />
          <span className={cn("tracking-tight font-bold", isScrolled ? "text-xl" : "text-2xl sm:text-3xl")}>Krita Compress</span>
        </Link>
        <nav className="space-x-2 sm:space-x-4 flex items-center">
          {/* Future navigation links can go here */}
          {pathname === '/' ? (
            <CompressNowButton />
          ) : (
            <Link href="/#image-compressor-section" passHref legacyBehavior>
              <a onClick={(e) => {
                  // if already on homepage but not at top, this helps smooth scroll
                  if (document.getElementById('image-compressor-section')) {
                    e.preventDefault();
                    document.getElementById('image-compressor-section')?.scrollIntoView({ behavior: 'smooth' });
                  }
                  // if not on homepage, Link will navigate, then browser should handle hash scroll
              }}>
                 <CompressNowButton />
              </a>
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
